# Attribution by entry origin (descriptive)

Descriptive attribution: each trade is credited to the mechanism that opened it. This is NOT the incremental (causal) effect of enabling a mechanism: enabling it changes which later signals are taken and so the whole trade sequence. The causal comparison is a complete ON run against an otherwise identical OFF run (path-dependent counterfactual).

## VGT

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 30 | 29 (5/24/0) | 1 | $15,188.05 | $52,891.13 | $2,925.00 | $34,778.08 | $11,223.85 |

Continuation: OFF.

Drawdown (minute / daily): $30,353.20 / $30,050.32. Total marked net: $26,411.90.

## GDX

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 11 | 11 (3/8/0) | 0 | −$23,816.62 | −$18,718.31 | $1,090.09 | $4,008.22 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $60,804.29 / $58,508.64. Total marked net: −$23,816.62.

## XBI

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 15 | 15 (2/13/0) | 0 | −$34,418.05 | −$25,698.77 | $1,486.40 | $7,232.88 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $44,828.01 / $42,817.62. Total marked net: −$34,418.05.


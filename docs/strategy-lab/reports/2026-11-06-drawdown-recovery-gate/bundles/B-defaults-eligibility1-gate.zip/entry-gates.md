# Entry trend filter and persistent eligibility (descriptive)

Trend filter: `{"enabled":false}`. Persistent eligibility: `{"enabled":true,"label":"1 — Time-limited opportunity","policy":"time_limited","maxAgeSessions":10}`.

Descriptive counts of one run. A blocked or added entry changes every later decision (path dependence), so these are not the effect of the filter or of eligibility; compare a complete ON run with an otherwise identical OFF run (tools/paired-comparison.ts). Retrospective historical data only; not evidence that a rule makes trading safer.

Terms: a **signal** is a raw Rise crossing (recorded once); an **armed opportunity** keeps it available (not an order, no capital reserved) for a bounded age; a **vetoed** crossing was blocked at its own decision with eligibility OFF (never replayed); a **deferred** one armed an opportunity that kept waiting; an **entry** is an actual fill at the next eligible trade at the then-current price.

## VGT

Raw crossings 116: taken 15, ignored while invested/pending 34, vetoed 0 (none), deferred 67.

Eligibility (time_limited): 82 opportunities (rise_from_recent_low 82, eligibility_renewal 0); ended by consumed 30, expired 13, invalidated 39, superseded 0, unfilled_at_end 0, end_of_data 0; invalidated by predicate_false 39; taken at arming 15, later 15; age at decision mean 1.77, max 10 session(s); renewal watches 0 (none).

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| latched:rise_from_recent_low | 15 | 14 (5/9/0) | 1 | $37,337.82 | $11,223.85 | $30,950.68 |
| rise_from_recent_low | 15 | 15 (0/15/0) | 0 | −$22,149.77 | $0.00 | $5,515.07 |

## GDX

Raw crossings 124: taken 4, ignored while invested/pending 1, vetoed 0 (none), deferred 119.

Eligibility (time_limited): 123 opportunities (rise_from_recent_low 123, eligibility_renewal 0); ended by consumed 11, expired 29, invalidated 83, superseded 0, unfilled_at_end 0, end_of_data 0; invalidated by predicate_false 83; taken at arming 4, later 7; age at decision mean 2.00, max 10 session(s); renewal watches 0 (none).

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| latched:rise_from_recent_low | 7 | 7 (2/5/0) | 0 | −$11,340.39 | $0.00 | $3,043.84 |
| rise_from_recent_low | 4 | 4 (1/3/0) | 0 | −$12,476.22 | $0.00 | $964.38 |

## XBI

Raw crossings 120: taken 2, ignored while invested/pending 3, vetoed 0 (none), deferred 115.

Eligibility (time_limited): 117 opportunities (rise_from_recent_low 117, eligibility_renewal 0); ended by consumed 15, expired 27, invalidated 75, superseded 0, unfilled_at_end 0, end_of_data 0; invalidated by predicate_false 75; taken at arming 2, later 13; age at decision mean 3.27, max 8 session(s); renewal watches 0 (none).

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| latched:rise_from_recent_low | 13 | 13 (2/11/0) | 0 | −$21,820.22 | $0.00 | $6,690.41 |
| rise_from_recent_low | 2 | 2 (0/2/0) | 0 | −$12,597.83 | $0.00 | $542.47 |


# Entry trend filter and persistent eligibility (descriptive)

Trend filter: `{"enabled":false}`. Persistent eligibility: `{"enabled":true,"label":"1 — Time-limited opportunity","policy":"time_limited","maxAgeSessions":10}`.

Descriptive counts of one run. A blocked or added entry changes every later decision (path dependence), so these are not the effect of the filter or of eligibility; compare a complete ON run with an otherwise identical OFF run (tools/paired-comparison.ts). Retrospective historical data only; not evidence that a rule makes trading safer.

Terms: a **signal** is a raw Rise crossing (recorded once); an **armed opportunity** keeps it available (not an order, no capital reserved) for a bounded age; a **vetoed** crossing was blocked at its own decision with eligibility OFF (never replayed); a **deferred** one armed an opportunity that kept waiting; an **entry** is an actual fill at the next eligible trade at the then-current price.

## VGT

Raw crossings 116: taken 52, ignored while invested/pending 64, vetoed 0 (none), deferred 0.

Eligibility (time_limited): 52 opportunities (rise_from_recent_low 52, eligibility_renewal 0); ended by consumed 52, expired 0, invalidated 0, superseded 0, unfilled_at_end 0, end_of_data 0; invalidated by nothing; taken at arming 52, later 0; age at decision mean 0.00, max 0 session(s); renewal watches 0 (none).

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 52 | 51 (13/38/0) | 1 | −$3,270.17 | $12,987.72 | $62,293.15 |

## GDX

Raw crossings 124: taken 85, ignored while invested/pending 39, vetoed 0 (none), deferred 0.

Eligibility (time_limited): 85 opportunities (rise_from_recent_low 85, eligibility_renewal 0); ended by consumed 85, expired 0, invalidated 0, superseded 0, unfilled_at_end 0, end_of_data 0; invalidated by nothing; taken at arming 85, later 0; age at decision mean 0.00, max 0 session(s); renewal watches 0 (none).

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 85 | 85 (22/63/0) | 0 | $9,941.94 | $0.00 | $41,709.59 |

## XBI

Raw crossings 120: taken 79, ignored while invested/pending 41, vetoed 0 (none), deferred 0.

Eligibility (time_limited): 79 opportunities (rise_from_recent_low 79, eligibility_renewal 0); ended by consumed 79, expired 0, invalidated 0, superseded 0, unfilled_at_end 0, end_of_data 0; invalidated by nothing; taken at arming 79, later 0; age at decision mean 0.00, max 0 session(s); renewal watches 0 (none).

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 79 | 78 (19/59/0) | 1 | −$71,691.80 | $26,675.67 | $40,805.48 |


# Strategy Lab research bundle — R-000004

**B-defaults-eligibility1-gate-OFF**

| | |
| --- | --- |
| Run | R-000004 (manual, completed); variation V-000004; experiment Growth Entry Discovery |
| Strategy | Growth — `rise-from-recent-low-trading@1.4.0` |
| Phenotype | none |
| Symbols | VGT, GDX, XBI |
| Window | 2016-01-04 → 2023-12-29 (New York session dates, inclusive); resolution 1d; partitions touched: training |
| Data | SIMULATED by Strategy Lab on real local minute data |
| Semantics | STANDALONE PER SYMBOL: each symbol is an independent backtest on its own $100,000 fixed notional (all-in or flat, never compounded). Per-symbol results are never summed and are not comparable with a shared-slot pool. |
| Completed | 2026-11-06T15:16:57.666Z (UTC) |

## What the numbers mean

- **Net P&L** = gross − per-side costs − margin interest (11% simple, per calendar day between session dates, 365-day year), on the fixed $100,000 notional. **Realized** = closed trades; **unrealized** = an open position marked at the last close net of accrued interest (its exit cost not charged).
- **Drawdowns** are falls of the marked net (realized + open position) from an earlier peak: *minute* at every minute close and session close, *daily* at session closes; % = of the $100,000 notional, not of equity.
- **Times** are stored in UTC (`…Z`); the `*_new_york` columns give America/New_York wall-clock time with EST/EDT. `time_precision`: minute, session-close (a daily bar's close), day (date only) or unknown.
- **Origin** (Growth 1.1.0+): `base_growth` = the Rise-from-Recent-Low entry; `continuation` = an entry of the selected continuation method. Origin-attributed P&L is DESCRIPTIVE: it is not the incremental effect of enabling a method, because enabling it changes the whole later trade sequence. Compare a complete ON run with an otherwise identical OFF run for the counterfactual.
- **Optional rules** (Growth 1.3.0, when ON): the entry method (`rise_from_recent_low` or `trend_breakout`; trades.csv `entry_source` `trend_breakout`), the initial risk stop (fixed at fill − m × ATR, active from the fill; exit reasons `initial stop` / `initial stop gap`) and trend retention (a partial sale at the first profit trailing-stop event, events.csv `SYM:T-n:partial-k` executed exits with `meta.partial`; the remainder's exit reason `trend exit` or a risk exit). A position sold in several fills is ONE trade row (its net = all its fills); exit-fills.csv has every fill with its principal repayment and interest; optional-rules.md the counts. Runs without these options have no exit-fills.csv and their trade rows are unchanged.
- **Drawdown Recovery Gate** (Growth 1.4.0, when ON): a filter on every Growth entry decision, never a signal, maintained on completed one-minute closes and closing prints whatever the bar resolution: entries are blocked while a significant chronological dip (a close at least d below the highest EARLIER close of the current session and the N before it) is unresolved, until the price recovers r of the whole decline and holds it at every observation for Y trading-session intervals (to the same New York time) or regains the peak. drawdown-episodes.csv / drawdown-transitions.csv hold its causal records; entry-decisions.csv its state at each decision (`blocked_by`, `via` = `drawdown_release` for a latched decision taken intraday at the release).
- **Entry gates** (Growth 1.2.0, when ON): the entry trend filter judges every entry decision on trading-session observations complete at the decision; persistent eligibility keeps a raw crossing available as an *opportunity* for a bounded number of sessions. `entry_source` (trades.csv): `rise_from_recent_low` (the crossing itself), `latched:…` (a later decision of an armed opportunity, filled at the then-current price), `eligibility_renewal` (a policy-5 renewal signal), `continuation:<method>`. A raw crossing appears once in events.csv; latched decisions and renewal signals are separate events (`SYM:latched:<t>`, `SYM:renewal:<t>`). See entry-decisions.csv, opportunities.csv and entry-gates.md.
- **Exploratory, not validated.** A single run on historical data (often already inspected) is not evidence of an edge, and a rerun of a study's phenotype on exposed dates is not another holdout.

## Files

| File | Contents |
| --- | --- |
| `artifacts/daily.json` | unmodified copy of the run artifact daily.json (sha256 verified against the run manifest) |
| `artifacts/decisions.json` | unmodified copy of the run artifact decisions.json (sha256 verified against the run manifest) |
| `artifacts/events.json` | unmodified copy of the run artifact events.json (sha256 verified against the run manifest) |
| `artifacts/manifest.json` | unmodified copy of the run artifact manifest.json |
| `artifacts/metrics.json` | unmodified copy of the run artifact metrics.json (sha256 verified against the run manifest) |
| `artifacts/provenance.json` | unmodified copy of the run artifact provenance.json (sha256 verified against the run manifest) |
| `artifacts/request.json` | unmodified copy of the run artifact request.json (sha256 verified against the run manifest) |
| `artifacts/trades.json` | unmodified copy of the run artifact trades.json (sha256 verified against the run manifest) |
| `attribution.json` | per-origin attribution (descriptive), continuation counts, drawdowns, P&L per symbol |
| `attribution.md` | the attribution tables in prose form |
| `daily-marks.csv` | daily marks per symbol (realized + open position marked net of interest at each close) |
| `decision-log.csv` | the chronological decision/state log (base signals, fills, exits with the net identity, continuation transitions) |
| `entry-decisions.csv` | every Growth entry decision judged by the entry gates (raw crossings, latched decisions, renewal signals, continuation triggers) with the observed trend values, the policy values, the trade and its final realized or open unrealized net |
| `entry-gates.md` | the entry trend filter and persistent eligibility: counts, ages and outcomes by entry source (descriptive) |
| `events.csv` | every event of the run (signals, executed entries and exits, rejected/suppressed signals) with UTC and ET times |
| `manifest.json` | sha256 and size of every file, provenance, unavailable items |
| `opportunities.csv` | every armed opportunity (persistent eligibility): signal, age bound, blocked evaluations, decision, how it ended, its trade and final net |
| `parameters.json` | parameter snapshot, effective values, saved-but-inactive values, parameter schema |
| `run.json` | the run record: inputs, assumptions, provenance, code revision, metrics, phenotype link |
| `trades.csv` | the trade ledger from trades.json (origin = the mechanism that opened the trade) |

## Not available in this bundle

- `minute-marks.csv.gz`: not included by default (large); export with "include minute marks" to add it
- `continuation-episodes.csv`: continuation was OFF, or no profitable exit opened a window
- `drawdown-episodes.csv`: the Drawdown Recovery Gate was OFF (or the run predates Growth 1.4.0)
- `drawdown-transitions.csv`: the Drawdown Recovery Gate was OFF (or the run predates Growth 1.4.0)
- `exit-fills.csv`: the initial risk stop and trend retention were OFF (or the run predates Growth 1.3.0): every trade is one exit fill, in trades.csv
- `optional-rules.md`: the breakout entry, the initial risk stop and trend retention were OFF (or the run predates Growth 1.3.0)
- `drawdown-gate.md`: the Drawdown Recovery Gate was OFF (or the run predates Growth 1.4.0)

## How to check it independently

1. `sha256sum` every file against `manifest.json`; the files under `artifacts/` also against `artifacts/manifest.json` (the run's own manifest, written when the run completed).
2. Per trade: `net_usd` = `gross_before_costs_usd` − `costs_usd` − `interest_usd` (to the cent); interest = 100,000 × 0.11 × calendar days between the entry and exit session dates / 365.
3. Entries and exits pair only by `trade_id` and `linked_event_id`; every executed entry fills strictly after its decision time.
4. Growth: the totals in `artifacts/metrics.json` (per symbol: realized + unrealized = total marked net) equal the sums of `trades.csv`.
5. The request (`artifacts/request.json`, parameters in `parameters.json`) plus the code revision in `run.json` reproduce the run: `node --experimental-transform-types apps/strategy-lab/scripts/replay-run.ts R-000004` on the machine that holds the data.

# Attribution by entry origin (descriptive)

Descriptive attribution: each trade is credited to the mechanism that opened it. This is NOT the incremental (causal) effect of enabling a mechanism: enabling it changes which later signals are taken and so the whole trade sequence. The causal comparison is a complete ON run against an otherwise identical OFF run (path-dependent counterfactual).

## VGT

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 52 | 51 (13/38/0) | 1 | −$3,270.17 | $62,463.99 | $5,128.68 | $60,605.48 | $12,987.72 |

Continuation: OFF.

Drawdown (minute / daily): $73,618.48 / $73,384.72. Total marked net: $9,717.54.

## GDX

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 85 | 85 (22/63/0) | 0 | $9,941.94 | $60,177.37 | $8,525.84 | $41,709.59 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $82,665.14 / $79,544.12. Total marked net: $9,941.94.

## XBI

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 79 | 78 (19/59/0) | 1 | −$71,691.80 | −$24,458.61 | $7,783.87 | $39,449.32 | $26,675.67 |

Continuation: OFF.

Drawdown (minute / daily): $94,981.62 / $94,703.90. Total marked net: −$45,016.13.


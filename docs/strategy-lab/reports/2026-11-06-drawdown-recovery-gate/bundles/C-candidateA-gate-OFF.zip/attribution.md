# Attribution by entry origin (descriptive)

Descriptive attribution: each trade is credited to the mechanism that opened it. This is NOT the incremental (causal) effect of enabling a mechanism: enabling it changes which later signals are taken and so the whole trade sequence. The causal comparison is a complete ON run against an otherwise identical OFF run (path-dependent counterfactual).

## VGT

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 20 | 20 (11/9/0) | 0 | $43,706.79 | $73,739.92 | $2,035.87 | $27,997.26 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $13,797.57 / $12,249.57. Total marked net: $43,706.79.

## GDX

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 4 | 4 (2/2/0) | 0 | −$6,197.63 | −$3,901.15 | $397.85 | $1,898.63 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $16,963.48 / $14,702.20. Total marked net: −$6,197.63.

## XBI

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 4 | 4 (2/2/0) | 0 | $2,382.24 | $4,622.71 | $402.11 | $1,838.36 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $15,374.15 / $14,741.76. Total marked net: $2,382.24.


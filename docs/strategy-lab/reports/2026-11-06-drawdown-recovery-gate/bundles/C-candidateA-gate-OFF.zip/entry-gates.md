# Entry trend filter and persistent eligibility (descriptive)

Trend filter: `{"enabled":true,"label":"C — Rising moving average","method":"rising_sma","movingAverageSessions":50,"slopeComparisonSessions":40}`. Persistent eligibility: `{"enabled":false}`.

Descriptive counts of one run. A blocked or added entry changes every later decision (path dependence), so these are not the effect of the filter or of eligibility; compare a complete ON run with an otherwise identical OFF run (tools/paired-comparison.ts). Retrospective historical data only; not evidence that a rule makes trading safer.

Terms: a **signal** is a raw Rise crossing (recorded once); an **armed opportunity** keeps it available (not an order, no capital reserved) for a bounded age; a **vetoed** crossing was blocked at its own decision with eligibility OFF (never replayed); a **deferred** one armed an opportunity that kept waiting; an **entry** is an actual fill at the next eligible trade at the then-current price.

## VGT

Raw crossings 69: taken 20, ignored while invested/pending 15, vetoed 34 (trend_veto 34), deferred 0.

Trend filter (rising_sma): 54 evaluations; blocked by decision kind: base_signal trend_veto 34.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 20 | 20 (11/9/0) | 0 | $43,706.79 | $0.00 | $27,997.26 |

## GDX

Raw crossings 83: taken 4, ignored while invested/pending 4, vetoed 75 (trend_veto 75), deferred 0.

Trend filter (rising_sma): 79 evaluations; blocked by decision kind: base_signal trend_veto 75.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 4 | 4 (2/2/0) | 0 | −$6,197.63 | $0.00 | $1,898.63 |

## XBI

Raw crossings 72: taken 4, ignored while invested/pending 2, vetoed 66 (trend_veto 66), deferred 0.

Trend filter (rising_sma): 70 evaluations; blocked by decision kind: base_signal trend_veto 66.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 4 | 4 (2/2/0) | 0 | $2,382.24 | $0.00 | $1,838.36 |


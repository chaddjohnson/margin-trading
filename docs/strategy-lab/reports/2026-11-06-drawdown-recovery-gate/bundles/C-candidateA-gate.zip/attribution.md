# Attribution by entry origin (descriptive)

Descriptive attribution: each trade is credited to the mechanism that opened it. This is NOT the incremental (causal) effect of enabling a mechanism: enabling it changes which later signals are taken and so the whole trade sequence. The causal comparison is a complete ON run against an otherwise identical OFF run (path-dependent counterfactual).

## VGT

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 8 | 8 (4/4/0) | 0 | $20,955.65 | $35,153.65 | $817.18 | $13,380.82 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $10,254.55 / $8,504.46. Total marked net: $20,955.65.

## GDX

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 2 | 2 (2/0/0) | 0 | $6,203.71 | $7,401.83 | $203.60 | $994.52 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $6,493.68 / $5,063.80. Total marked net: $6,203.71.

## XBI

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 1 | 1 (1/0/0) | 0 | $7,204.31 | $7,699.89 | $103.80 | $391.78 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $4,375.30 / $3,855.75. Total marked net: $7,204.31.


# Entry trend filter and persistent eligibility (descriptive)

Trend filter: `{"enabled":true,"label":"C — Rising moving average","method":"rising_sma","movingAverageSessions":50,"slopeComparisonSessions":40}`. Persistent eligibility: `{"enabled":false}`.

Descriptive counts of one run. A blocked or added entry changes every later decision (path dependence), so these are not the effect of the filter or of eligibility; compare a complete ON run with an otherwise identical OFF run (tools/paired-comparison.ts). Retrospective historical data only; not evidence that a rule makes trading safer.

Terms: a **signal** is a raw Rise crossing (recorded once); an **armed opportunity** keeps it available (not an order, no capital reserved) for a bounded age; a **vetoed** crossing was blocked at its own decision with eligibility OFF (never replayed); a **deferred** one armed an opportunity that kept waiting; an **entry** is an actual fill at the next eligible trade at the then-current price.

## VGT

Raw crossings 69: taken 8, ignored while invested/pending 9, vetoed 52 (trend_veto 34), deferred 0.

Trend filter (rising_sma): 60 evaluations; blocked by decision kind: base_signal trend_veto 34/drawdown_gate 18.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 8 | 8 (4/4/0) | 0 | $20,955.65 | $0.00 | $13,380.82 |

## GDX

Raw crossings 83: taken 2, ignored while invested/pending 3, vetoed 78 (trend_veto 75), deferred 0.

Trend filter (rising_sma): 80 evaluations; blocked by decision kind: base_signal trend_veto 75/drawdown_gate 3.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 2 | 2 (2/0/0) | 0 | $6,203.71 | $0.00 | $994.52 |

## XBI

Raw crossings 72: taken 1, ignored while invested/pending 0, vetoed 71 (trend_veto 66), deferred 0.

Trend filter (rising_sma): 72 evaluations; blocked by decision kind: base_signal trend_veto 66/drawdown_gate 5.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 1 | 1 (1/0/0) | 0 | $7,204.31 | $0.00 | $391.78 |


# Entry trend filter and persistent eligibility (descriptive)

Trend filter: `{"enabled":false}`. Persistent eligibility: `{"enabled":false}`.

Descriptive counts of one run. A blocked or added entry changes every later decision (path dependence), so these are not the effect of the filter or of eligibility; compare a complete ON run with an otherwise identical OFF run (tools/paired-comparison.ts). Retrospective historical data only; not evidence that a rule makes trading safer.

Terms: a **signal** is a raw Rise crossing (recorded once); an **armed opportunity** keeps it available (not an order, no capital reserved) for a bounded age; a **vetoed** crossing was blocked at its own decision with eligibility OFF (never replayed); a **deferred** one armed an opportunity that kept waiting; an **entry** is an actual fill at the next eligible trade at the then-current price.

## VGT

Raw crossings 116: taken 24, ignored while invested/pending 24, vetoed 68 (none), deferred 0.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 24 | 23 (3/20/0) | 1 | −$5,465.51 | −$372.32 | $23,597.26 |

## GDX

Raw crossings 124: taken 4, ignored while invested/pending 1, vetoed 119 (none), deferred 0.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 4 | 4 (1/3/0) | 0 | −$12,476.22 | $0.00 | $964.38 |

## XBI

Raw crossings 120: taken 3, ignored while invested/pending 1, vetoed 116 (none), deferred 0.

| Entry source | Entries | Closed (W/L/0) | Open | Realized net | Unrealized | Interest |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| rise_from_recent_low | 3 | 3 (0/3/0) | 0 | −$13,875.19 | $0.00 | $783.56 |


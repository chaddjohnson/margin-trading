# Drawdown Recovery Gate (descriptive)

Configuration: dip lookback N = 30 sessions, significant decline d = 5%, required retracement r = 70% of the whole decline, confirmation Y = 2 session interval(s).

Conventions:

- A filter on every Growth entry decision (base signal, latched opportunity, renewal, continuation trigger), never an entry signal; exits are never filtered.
- Observations: every completed regular-session one-minute close (at the minute end) and the closing print (at the scheduled close) are full observations; the opening trade and the reopening trade after missing minutes only test continuity. A minute’s high and low are never used.
- Detection: a close at least d below the highest EARLIER close of the current session and the N sessions before it (the peak precedes the trough). The window only discovers; an episode stays until a close regains its peak (then a fresh detection epoch starts).
- Threshold: trough + (peak − trough) × r; a lower trough moves it and restarts the confirmation.
- Confirmation: from the first full observation at/above the threshold (session 0), every later observation stays at/above it until the first full observation in session 0 + Y at/after the same New York time (or later: early close, missing minute). Y = 0: at once.
- Blocking states: recovery required, and the discovery window reaching before the loaded data (insufficient history). With persistent eligibility ON an armed opportunity blocked by the gate may be decided at the release minute (fill at the next eligible trade); OFF, a blocked signal is never replayed.

Counts are descriptive: a blocked or delayed entry changes every later decision (path dependence), so they are not per-trade causal effects. Compare an otherwise identical run with the gate OFF.

## VGT

- Episodes: 23 (resolved 23, of which 8 by regaining the peak before a confirmation; unresolved at the end {}; detected in the warm-up 0; detected while the window was incomplete 1).
- Deepest decline per episode (%): mean 11.5789, median 8.4055, max 37.3909. Sessions from detection to resolution: median 26, max 477.
- Recovery streaks started 461; confirmed 28; reset before confirming 425; confirmations lost 13; resets by cause {"opening_gap":11,"reopen_gap":56,"minute_close":371,"closing_print":0,"new_trough":0}.
- Releases (blocking → permissive): 36 {"recovery_confirmed":28,"dip_resolved":8}.
- Blocked entry decisions: 68 {"base_signal":68} (a latched opportunity once per blocked stretch); blocked crossings 68 {"vetoed":68}; blocked continuation triggers 0.
- Opportunities the gate blocked at least once: 0; later entered: 0; decisions at a release instant: 0 taken of 0.
- Trades from an opportunity the gate had blocked: 0 (closed 0, wins 0, realized net $0).
- Gate state at the window’s session closes: {"normal":854,"recovery_required":931,"recovery_confirmed":197,"insufficient_history":30}; at the end: normal.

## GDX

- Episodes: 21 (resolved 20, of which 17 by regaining the peak before a confirmation; unresolved at the end {"recovery_required":1}; detected in the warm-up 0; detected while the window was incomplete 3).
- Deepest decline per episode (%): mean 13.2903, median 8.8264, max 52.9612. Sessions from detection to resolution: median 6, max 919.
- Recovery streaks started 307; confirmed 10; reset before confirming 282; confirmations lost 7; resets by cause {"opening_gap":11,"reopen_gap":0,"minute_close":277,"closing_print":1,"new_trough":0}.
- Releases (blocking → permissive): 25 {"dip_resolved":15,"recovery_confirmed":10}.
- Blocked entry decisions: 119 {"base_signal":119} (a latched opportunity once per blocked stretch); blocked crossings 119 {"vetoed":119}; blocked continuation triggers 0.
- Opportunities the gate blocked at least once: 0; later entered: 0; decisions at a release instant: 0 taken of 0.
- Trades from an opportunity the gate had blocked: 0 (closed 0, wins 0, realized net $0).
- Gate state at the window’s session closes: {"normal":77,"recovery_required":1818,"recovery_confirmed":87,"insufficient_history":30}; at the end: recovery_required.

## XBI

- Episodes: 17 (resolved 16, of which 10 by regaining the peak before a confirmation; unresolved at the end {"recovery_required":1}; detected in the warm-up 0; detected while the window was incomplete 1).
- Deepest decline per episode (%): mean 16.822, median 9.7498, max 64.4419. Sessions from detection to resolution: median 19.5, max 472.
- Recovery streaks started 700; confirmed 24; reset before confirming 666; confirmations lost 18; resets by cause {"opening_gap":13,"reopen_gap":1,"minute_close":670,"closing_print":0,"new_trough":0}.
- Releases (blocking → permissive): 34 {"recovery_confirmed":24,"dip_resolved":10}.
- Blocked entry decisions: 116 {"base_signal":116} (a latched opportunity once per blocked stretch); blocked crossings 116 {"vetoed":116}; blocked continuation triggers 0.
- Opportunities the gate blocked at least once: 0; later entered: 0; decisions at a release instant: 0 taken of 0.
- Trades from an opportunity the gate had blocked: 0 (closed 0, wins 0, realized net $0).
- Gate state at the window’s session closes: {"normal":203,"recovery_required":1654,"recovery_confirmed":125,"insufficient_history":30}; at the end: recovery_required.


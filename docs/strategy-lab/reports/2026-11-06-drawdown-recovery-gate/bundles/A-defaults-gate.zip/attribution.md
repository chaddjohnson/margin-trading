# Attribution by entry origin (descriptive)

Descriptive attribution: each trade is credited to the mechanism that opened it. This is NOT the incremental (causal) effect of enabling a mechanism: enabling it changes which later signals are taken and so the whole trade sequence. The causal comparison is a complete ON run against an otherwise identical OFF run (path-dependent counterfactual).

## VGT

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 24 | 23 (3/20/0) | 1 | −$5,465.51 | $20,229.76 | $2,308.97 | $23,386.30 | −$372.32 |

Continuation: OFF.

Drawdown (minute / daily): $31,939.46 / $31,636.58. Total marked net: −$5,837.83.

## GDX

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 4 | 4 (1/3/0) | 0 | −$12,476.22 | −$11,117.60 | $394.24 | $964.38 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $13,088.76 / $12,596.52. Total marked net: −$12,476.22.

## XBI

| Origin | Entries | Closed (W/L/0) | Open | Realized net | Gross before costs | Costs | Interest | Unrealized |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base_growth | 3 | 3 (0/3/0) | 0 | −$13,875.19 | −$12,798.18 | $293.45 | $783.56 | $0.00 |

Continuation: OFF.

Drawdown (minute / daily): $15,515.37 / $15,050.46. Total marked net: −$13,875.19.


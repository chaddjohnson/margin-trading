# VERIFICATION — handoff ZIP extraction and checksum report

Built by `tools/tsla-outcome-identity-fix/bundle.sh` from fix commit `70f8bdf14712924fe02985515537b111e00a5edd` on `fix/tsla-outcome-identity-join`.

## Pass 1 (every file of this bundle except this report)

- archive sha256 `13461a4f60b2e4ff55ed706657b191709347857ec91d3607c372dabcf9e39f8c`, 55 files listed in SHA256SUMS.txt
```
test of tsla-outcome-identity-fix-handoff.zip OK
checksums OK after extraction: 55 files
secrets / personal-data scan: clean (patterns and every .env value); no database, archive, binary or market-data file; no file over 5 MB; the 5 sealed reference inputs equal their pins
```

## Final archive

The final archive is pass 1 plus this report, with SHA256SUMS.txt regenerated over every file. It is verified the
same way (zip -T; extraction; `sha256sum -c SHA256SUMS.txt`; the scans; the five reference inputs against their
pins). Its own sha256 is recorded outside the archive in `docs/engineering/tsla-outcome-identity-fix/bundle/FINAL_VERIFICATION.txt` and in the final report.

## How to re-verify after download

```
unzip tsla-outcome-identity-fix-handoff.zip && cd tsla-outcome-identity-fix-handoff && sha256sum -c SHA256SUMS.txt
```

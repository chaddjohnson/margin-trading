# gpu-phase3 — run commands (as executed)

Working directory `/home/chad/projects/margin-trading`, branch `research/gpu-phase3`. Node v24.21.0 (units use
`/home/chad/.local/share/fnm/node-versions/v24.21.0/installation/bin/node`). Shorthand:
`NODE="node --experimental-transform-types --disable-warning=ExperimentalWarning"`. Times UTC. Long runs are transient
systemd user units in `gpup3.slice` (MemoryHigh 44G, MemoryMax 48G, MemorySwapMax 0) via
`tools/gpu-phase3/launch.sh <unit> <abs log> [--wait] -- <command>`. Unit logs (`results/logs/`, git-ignored) are copied
to `results/runlogs/` at the end.

## Stage 0 (13:55–14:05)

```bash
git switch -c research/gpu-phase3                       # from research/gpu-phase2 a1836407
$NODE src/gpu-backend/compat.ts                          # f67dcb3b… = the Phase 2 acceptance
# checkAcceptance({ binary: research/gpu-phase2/build/gb2, uuid }) → ACCEPTED
gh api repos/chaddjohnson/margin-trading/branches/main/protection   # 404 "Branch not protected"
```

## Stage 1 — the accepted Phase 2 path (14:05–15:24)

```bash
# development captures of real batches (Phase 2 binary): research/gpu-phase3/cache/captures/ (git-ignored)
GPU_POLICY_PURPOSE=benchmark $NODE tools/gpu-phase3/capture.ts --name d19-base-4096 --door D19 --options base --refs --random 4096
#   … d24-detail-risk-1024, d24-all-512, d24-periods-512, d24-blackout-trades-256, s3-all-256, full-base-1024
tools/gpu-phase3/launch.sh gpup3-baseline $PWD/research/gpu-phase3/results/logs/baseline-chain.txt -- /bin/bash research/gpu-phase3/chains/baseline.sh
# p2-a2-r1's final dump failed after its job-end (V8 string limit); recovered read-only:
GPU_POLICY_PURPOSE=benchmark $NODE --max-old-space-size=12000 tools/gpu-phase3/archive-digest.ts p2-a2-r1/gpu
$NODE tools/gpu-phase3/compare.ts sealed p2-a2-r1/gpu a2 C19 base --out research/gpu-phase3/results/optimizer/compare-p2-a2-r1-vs-sealed.json
for i in 1 2 3; do GPU_POLICY_PURPOSE=benchmark $NODE --expose-gc tools/gpu-phase3/replay.ts --backend gpu --run p2-mini-r$i --job mini --batch 8192 --linger 30; done
$NODE tools/gpu-phase3/compare.ts arms p2-mini-r1/gpu p2-mini-r2/gpu --out research/gpu-phase3/results/optimizer/compare-p2-mini-r1-vs-r2.json
```

Protocol frozen 14:21:42Z (`results/protocol-freeze.json`); commits `b4424384`, `628d450a`.

## Stage 2 — Priority A (15:24–)

```bash
research/gpu-phase3/cache/staged/apply.sh      # staged edits of existing backend files (+ prettier); commit 37f67004
GPU_POLICY_PURPOSE=parity-test $NODE tools/gpu-phase3/offline-check.ts --workers 1,2,3,8 --out research/gpu-phase3/results/dev/offline-check-a.json
tools/gpu-phase3/launch.sh gpup3-devcheck-a $PWD/research/gpu-phase3/results/logs/devcheck-a.txt -- /usr/bin/env HW=8 TAG=a /bin/bash research/gpu-phase3/chains/devcheck.sh   # mini FAILED closed (start race)
# fix cb7d129c; then
tools/gpu-phase3/launch.sh gpup3-devcheck-b $PWD/research/gpu-phase3/results/logs/devcheck-b.txt -- /usr/bin/env HW=8 TAG=b /bin/bash research/gpu-phase3/chains/devcheck.sh   # pass
tools/gpu-phase3/launch.sh gpup3-sweep $PWD/research/gpu-phase3/results/logs/sweep-s2.txt -- /usr/bin/env TAG=s2 VARIANTS="w8-b8192 w4-b8192 w12-b8192 w8-b16384" /bin/bash research/gpu-phase3/chains/sweep.sh
```

## Stage 2 measurement, Stage 4 dry runs, final binary (16:02–17:22)

```bash
tools/gpu-phase3/launch.sh gpup3-sweep $PWD/research/gpu-phase3/results/logs/sweep-s2.txt -- /usr/bin/env TAG=s2 VARIANTS="w8-b8192 w4-b8192 w12-b8192 w8-b16384" /bin/bash research/gpu-phase3/chains/sweep.sh
tools/gpu-phase3/build-final.sh                         # gb3 06a4a04a… (twice: reproducible), gb3-dev/-perturbed/-stale; kernels = Phase 2's
GPU_POLICY_PURPOSE=parity-test $NODE tools/gpu-phase3/negative.ts --out research/gpu-phase3/results/dev/negative-dry.json --host-workers 3
GPU_POLICY_PURPOSE=parity-test $NODE tools/gpu-phase3/tamper.ts --out research/gpu-phase3/results/dev/tamper-dry.json
GPU_POLICY_PURPOSE=parity-test $NODE --expose-gc tools/gpu-phase3/sustained.ts --minutes 2 --smoke --out-dir research/gpu-phase3/results/dev/sustained-smoke --host-workers 8
```

## Stage 5 — the final acceptance campaign (17:22–21:05) and the post-final chain (from 21:05)

```bash
tools/gpu-phase3/launch.sh gpup3-final $PWD/research/gpu-phase3/results/logs/final-chain.txt -- /usr/bin/env START=1 HW=8 /bin/bash research/gpu-phase3/chains/final.sh
tools/gpu-phase3/launch.sh gpup3-post-final $PWD/research/gpu-phase3/results/logs/post-final-chain.txt -- /usr/bin/env START=1 /bin/bash research/gpu-phase3/chains/post-final.sh
```

## Amendment A1 reruns, acceptance (22:55–23:03)

```bash
tools/gpu-phase3/launch.sh gpup3-reruns $PWD/research/gpu-phase3/results/logs/reruns-chain.txt -- /usr/bin/env START=1 /bin/bash research/gpu-phase3/chains/acceptance-reruns.sh
GPU_POLICY_PURPOSE=parity-test $NODE tools/gpu-phase3/accept.ts                 # ACCEPTED 23:02:38Z; commit ce24a977
sha256sum config/gpu-backend/acceptance.json                                    # b08738bea6f40aa2fb04f92e8601d035ec3dd11a33dcaf924d73d33777805214
GPU_POLICY_PURPOSE=parity-test $NODE --test src/gpu-backend/tests/{policy,enforcement,hostPipeline,layout}.test.ts   # 19/19
tools/gpu-backend/verify-acceptance.sh --device --expect-record-sha256 b08738bea6f40aa2fb04f92e8601d035ec3dd11a33dcaf924d73d33777805214   # VERIFIED
```

## Stage 7 — integration (23:03–23:07)

```bash
$NODE tools/gpu-phase3/merge-audit.ts research/gpu-phase3                       # results/integration/merge-audit.json; commit fc8923b0
git ls-remote origin refs/heads/main                                            # 10ca3422 (unchanged)
git push -u origin research/gpu-phase3                                          # fc8923b0 (unsandboxed)
git switch main && git merge --no-ff research/gpu-phase3                        # 30801fd4; tree d0341679 = the branch's
tools/gpu-phase3/launch.sh gpup3-post-merge $PWD/research/gpu-phase3/results/logs/post-merge-chain.txt --wait -- /usr/bin/env RECORD_SHA=b08738bea6f40aa2fb04f92e8601d035ec3dd11a33dcaf924d73d33777805214 /bin/bash research/gpu-phase3/chains/post-merge.sh   # pass; commit 6ceb76aa
```

## Stage 8 — manifest, bundle, fast-forwards, pushes, restoration

```bash
GPU_POLICY_PURPOSE=benchmark $NODE tools/gpu-phase3/manifest.ts                # research/gpu-phase3/MANIFEST.json
tools/gpu-phase3/bundle.sh <scratchpad>/bundle                                  # research/gpu-phase3/bundle/gpu-phase3-final-handoff.zip
git fetch . main:research/gpu-phase3 main:research/gpu-phase2                   # fast-forward only
git push origin main research/gpu-phase3 research/gpu-phase2                    # unsandboxed; then git ls-remote origin
git switch research/gpu-phase2                                                  # the branch active at the start
```

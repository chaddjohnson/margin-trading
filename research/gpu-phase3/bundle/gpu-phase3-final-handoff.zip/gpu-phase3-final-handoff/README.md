# GPU Phase 3 — final handoff bundle

Start with `GPU_ENGINE_FINAL_HANDOFF.md`. The six reports and `MANIFEST.json` at this level are copies of the files in
`research/gpu-phase3/`; paths such as `results/…` inside the reports are relative to that directory, where the
machine-readable evidence lies. `CHECKSUMS.sha256` lists the sha256 of every file (`sha256sum -c CHECKSUMS.sha256`).
Risk-envelope pilot NOT STARTED.

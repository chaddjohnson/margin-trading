# OMITTED ARTIFACTS — P6-TSLA handoff

Nothing below is needed to read the findings; everything is needed only to replay or audit at lane level.
Sizes in bytes; sha256 recomputed at packaging.

## 1. Per-lane search and qualification records (in the repository, not in the ZIP)

Committed on branch `research/tsla-d1-growth` at `447ac7cee7b263a27297df6e79f29b52bbcf4e70` (and sealed: `study/results/seals.jsonl`). Restore:
`git fetch origin research/tsla-d1-growth && git checkout 447ac7cee7b263a27297df6e79f29b52bbcf4e70 -- <path>`. Compact per-lane summary in the ZIP:
`study/reports/tables/lanes.csv` (one row per lane: islands, requested, stop reason, best feasible net).

| Path | Bytes | sha256 |
|---|---:|---|
| `research/tsla-d1-growth/results/qualification/C19/C-fixed.json` | 117465 | `b5f589599732b4348d03551ae0dbedd42e16ead1dc72c334425390af82b418e6` |
| `research/tsla-d1-growth/results/qualification/C19/D-broad.json` | 1681803 | `f8a87fb5bc2f607d579f3efb6a585368d6f2cd14852c97a68bb257af2fbd972f` |
| `research/tsla-d1-growth/results/qualification/C19/D-refine.json` | 2959324 | `93a43a56cc50e21825ea1ef5dcc8d9650cc7b648aa6f6eb9a267185a51750af7` |
| `research/tsla-d1-growth/results/qualification/C19/G-broad.json` | 2523548 | `a158e03788b0b80078e05445c704713d6519f9a603096b6283568d3f153aacec` |
| `research/tsla-d1-growth/results/qualification/C19/G-refine.json` | 2240259 | `b0b258d5f7d62369228b22a24792ab27cd9261966069384a31533ddce9cf3270` |
| `research/tsla-d1-growth/results/qualification/C19/J-broad.json` | 11168001 | `9edc3f4f77902228682d863bacab4a6bdce4e856c801b20d8978762a590fa735` |
| `research/tsla-d1-growth/results/qualification/C19/J-refine.json` | 6797136 | `f092ca446891fefa716e4d0558c3296d7c31c58edae7ff9658cac5372aefdfc8` |
| `research/tsla-d1-growth/results/qualification/C19/S-broad.json` | 9793676 | `96517157cc8cd88c47dd2156c9be4b71694334c216fc11ba93bca5564b524563` |
| `research/tsla-d1-growth/results/qualification/C19/S-refine.json` | 5130631 | `91074370d821a74ef9e635e4544c672948909f555c5d01fabc1ea827b7877c66` |
| `research/tsla-d1-growth/results/qualification/C21/C-fixed.json` | 175983 | `b1954bbe0b5c7b2ef178fb0138774ef6221ed8b237782e6f60fd214f05e8b0d8` |
| `research/tsla-d1-growth/results/qualification/C21/D-broad.json` | 1280137 | `b2d8d7a595fa8e3abc30ecac29a396293420d5d1686dacfda89d374b8f796d45` |
| `research/tsla-d1-growth/results/qualification/C21/D-refine.json` | 1320417 | `c0af27c41dfe8d3e692f46698e59f5561f9b54edff9716ab2855b2559a95590d` |
| `research/tsla-d1-growth/results/qualification/C21/G-broad.json` | 2486727 | `0613cffc90322d1e3445a46db6377ee50b674ab0f73e25967af6264bce4baa49` |
| `research/tsla-d1-growth/results/qualification/C21/G-refine.json` | 2259522 | `67c19e5e42bbe5415717101701a2ba3416f265534d935d6a3d17e5603bd49418` |
| `research/tsla-d1-growth/results/qualification/C21/J-broad.json` | 5768924 | `54b621d752bceb936b454636d3f16b357f69dfbb4ae510c1361b3c15c3ae23da` |
| `research/tsla-d1-growth/results/qualification/C21/J-refine.json` | 6850837 | `0643ff8971f7b387492d833e33c55930222b902f926ef135ae9b8f248e7beae5` |
| `research/tsla-d1-growth/results/qualification/C21/S-broad.json` | 9339639 | `cda3fb43a82746181c2781ebce462c12995d5d27425ab10c23c1b1881b725942` |
| `research/tsla-d1-growth/results/qualification/C21/S-refine.json` | 4917391 | `8b4966ef44810674b1d4e5009535cb0bfa1e84de6f41de62ba9445ce9bd39005` |
| `research/tsla-d1-growth/results/qualification/C23/C-fixed.json` | 118535 | `9db82d19650ee2a8747b88308df9449048fd73d964a78576100f20fb5d0d4f4c` |
| `research/tsla-d1-growth/results/qualification/C23/D-broad.json` | 865847 | `c9de9db4a952c480a6e1095a2feeee73b25befa1a5f504f3de8b913ee27b8343` |
| `research/tsla-d1-growth/results/qualification/C23/D-refine.json` | 1460289 | `739a7820c4b2d3bfecb06ef244dd872b9249a53d5fc0869990496efb3639f9b3` |
| `research/tsla-d1-growth/results/qualification/C23/G-broad.json` | 3412790 | `20afe7a913e14f67bd7ddc062c0e2a37b5dfdbfcb1f04f15ad806b1aa8da4d42` |
| `research/tsla-d1-growth/results/qualification/C23/G-refine.json` | 2225392 | `0776d901ed1b53283f98c315f9ee733ba5fcee8a45e45df239719970964c93c6` |
| `research/tsla-d1-growth/results/qualification/C23/J-broad.json` | 6578482 | `babd3d586221a311d4577f07d3ac42b7a6c338cb1b9830db6b78ae294f645abf` |
| `research/tsla-d1-growth/results/qualification/C23/J-refine.json` | 7173922 | `eefe6c559a0199692eddff6add02e0f2a6caf2bb51ebfa26f726f7d8b81461d6` |
| `research/tsla-d1-growth/results/qualification/C23/S-broad.json` | 8837304 | `033fe91cde27d05de3373d4bd29dba5b0aecd7934b9ab46b9db170bce1acb137` |
| `research/tsla-d1-growth/results/qualification/C23/S-refine.json` | 4774000 | `183dcc75bcad0600fa36bacf71c2fc9c3cc9d7d0b6d8a2dfe921fb3402ba9573` |
| `research/tsla-d1-growth/results/qualification/C24/C-fixed.json` | 177541 | `ce03a6985a8f5ece0ee89f1485420f9328f689075a849c51093c4c378933ced8` |
| `research/tsla-d1-growth/results/qualification/C24/D-broad.json` | 1266933 | `33af0e0b755e0f0ac881132bf00e78bd68398a1ee5d6173cea9ac1d036b356be` |
| `research/tsla-d1-growth/results/qualification/C24/D-refine.json` | 1462912 | `bae3cf837f381b4987650191af4c14f2afffa55184e9fa904b885910c3101a88` |
| `research/tsla-d1-growth/results/qualification/C24/G-broad.json` | 2493687 | `18c4dd31182a855e184fc4733d5cd1ffaae1009b312eb4634d16dcb29c90283a` |
| `research/tsla-d1-growth/results/qualification/C24/G-refine.json` | 2293374 | `c5a1fd182194bedb09241912cff3d55acbdfd1a9268375e669b7ba9aba7bc318` |
| `research/tsla-d1-growth/results/qualification/C24/J-broad.json` | 3647605 | `fda0ec2e1c394eb66a161d01c082a337bd5eed1155eedd54f754d8f7d2a7306d` |
| `research/tsla-d1-growth/results/qualification/C24/J-refine.json` | 7218270 | `b9437307ffd5835038163f2fa4b46d40a06032bafcbae94a50813708b23e1241` |
| `research/tsla-d1-growth/results/qualification/C24/S-broad.json` | 9550082 | `311bba27c15f6a80bd7edfbbdd44eaac754900e26a4b24f4ca90afcd88e62bfb` |
| `research/tsla-d1-growth/results/qualification/C24/S-refine.json` | 5103965 | `28c32bf434cf4efcb9a2c8e654f7e5fab4801f2cc9a6e89adc1adb3ce388f823` |
| `research/tsla-d1-growth/results/search/C19/D-broad.json` | 1275845 | `e3671637ae28a43efaa1547fd6743054b4ed43cdb8e6a5f9b5fceae2f299a8ed` |
| `research/tsla-d1-growth/results/search/C19/D-refine.json` | 1953070 | `f49adaa1af804fdca0b103f7b0e8903f5e601499220a68898a55d3980d16740c` |
| `research/tsla-d1-growth/results/search/C19/G-broad.json` | 1964732 | `7d0cc3cbfa821e78ef184d272a17054e2e0f1073c026f571c357d93f1b9c89f8` |
| `research/tsla-d1-growth/results/search/C19/G-refine.json` | 1500492 | `38677e4d850e2ffb7fe8a0513baa578ec5366a6c7e024452d835fa0009d68e02` |
| `research/tsla-d1-growth/results/search/C19/J-broad.json` | 9232336 | `8a7061b69c2f53f654884fc453ac3d0d4932f4cccf5ffd41c8a1f8df1592659d` |
| `research/tsla-d1-growth/results/search/C19/J-refine.json` | 4605861 | `64ad239d4a328e912b6db8d77062020dd0912029e7f9b2fe618231c2bf82998d` |
| `research/tsla-d1-growth/results/search/C19/S-broad.json` | 7222740 | `c54cfeb3ec275b4111a03edc83c4cfd9e744ebc17d9ea5ffb09419c208e542bb` |
| `research/tsla-d1-growth/results/search/C19/S-refine.json` | 3351602 | `87b381a1bf412daf744f90c59a1c394ae4e84e2f669332ff0bb9903db1e2151a` |
| `research/tsla-d1-growth/results/search/C21/D-broad.json` | 940909 | `596c105525577a04ed2449406b92b78c5713adfc38d74909827bf309e6ea31a8` |
| `research/tsla-d1-growth/results/search/C21/D-refine.json` | 1007756 | `f2b48fb217523d0a80e18c0997a4bbb7ad8513c2eda6af99c8119983d9e60b91` |
| `research/tsla-d1-growth/results/search/C21/D-rx1.json` | 237934 | `a8c2bcf2dc430d99130997faa921275eeadb1f745565eb7b8686c5a2b9e44f59` |
| `research/tsla-d1-growth/results/search/C21/D-rx2.json` | 233809 | `3b4b13e0571f8b9168387a625591764dd16ddee9650dae5f5e1b0fc7fafdace1` |
| `research/tsla-d1-growth/results/search/C21/G-broad.json` | 2003651 | `126c0ad939d7af6f8e35a83f042d3a9583f02e64bb7e35dddd984d12258061f2` |
| `research/tsla-d1-growth/results/search/C21/G-refine.json` | 1485400 | `9dfc13f277b6ff03ea78a4499afe54a502d7bf2054b0df3662db83844688169d` |
| `research/tsla-d1-growth/results/search/C21/J-broad.json` | 7033150 | `2c3caf82df8b037b50bc8501bb4ff53ed01f124fddf71d94af080140e1c844dc` |
| `research/tsla-d1-growth/results/search/C21/J-refine.json` | 4461475 | `7d7f9db3cb90af64ab5e97eaf1c2c320cd1020410c87d6a621c3f3d9d766b35b` |
| `research/tsla-d1-growth/results/search/C21/S-broad.json` | 7365040 | `678ff438df02333d98fd01ce7cc0fef69d33d46aa88598eba65e01e59315d03d` |
| `research/tsla-d1-growth/results/search/C21/S-refine.json` | 3440448 | `69236eb09286b71e94ca2fcec762665a6980fd144fe84e464e26bb2ebfbb0163` |
| `research/tsla-d1-growth/results/search/C23/D-broad.json` | 941698 | `230d8050345179be7327cb8ce8badb200d97dcb9ee97e22d7ad220405cf9df54` |
| `research/tsla-d1-growth/results/search/C23/D-refine.json` | 1004429 | `c8c9f63581c509081da92ca70e811deb2c0641d8418bb52be60160a27b392932` |
| `research/tsla-d1-growth/results/search/C23/G-broad.json` | 1986546 | `cff5c04faa340ce7870a0add32e3c4b6138e8fbdb5deda15ed4db9fd57f06865` |
| `research/tsla-d1-growth/results/search/C23/G-refine.json` | 1475680 | `ed9cab36f3d443c259d0c8f65067785d87b24b7f60fd845b7422124ae3230e45` |
| `research/tsla-d1-growth/results/search/C23/G-rx1.json` | 254220 | `6f748827b796877914b5f7dfbd30b65983bf0160462199cfc39437bd19f96fd0` |
| `research/tsla-d1-growth/results/search/C23/G-rx2.json` | 244590 | `594ea047364bab8e2e93c10b2fdc95ccef1cd5954f94badb1462a4cb243f6268` |
| `research/tsla-d1-growth/results/search/C23/G-rx3.json` | 257002 | `c59ce27d2b25fa3f5394ce30df05b85d3a16d67db53b9f613d5e592c11b74d94` |
| `research/tsla-d1-growth/results/search/C23/J-broad.json` | 6318089 | `009303f04d643e7a2d8e56ccad9f02a6b1c40186ee6c317c2fcad9ecb3c1ab16` |
| `research/tsla-d1-growth/results/search/C23/J-refine.json` | 4669253 | `9cb39361ae37ac46cadeda01d026063fd0f06e74a804494188f63982b81c86c1` |
| `research/tsla-d1-growth/results/search/C23/J-rx1.json` | 1522732 | `957e27537a560545415bb47ca96a023ea9c3dc0304ac27046f0f7ace54b70a93` |
| `research/tsla-d1-growth/results/search/C23/J-rx2.json` | 1683613 | `da72faa4abf41d912384c266f04843190f782cc9082dc00e026b3f32d64465ea` |
| `research/tsla-d1-growth/results/search/C23/J-rx3.json` | 1511630 | `f90760f29a1dfed1f53ba94ac7209fb3cdb0ab945e37adc6527199d634363c72` |
| `research/tsla-d1-growth/results/search/C23/S-broad.json` | 7085938 | `3221c659499c8394228fcba6fc87303e17c5af6ffc3e65b2e4855833f9f43362` |
| `research/tsla-d1-growth/results/search/C23/S-refine.json` | 3349290 | `9ceace8c720bf80e75137e8cc4d38a2d13b197890b6e2f70d15119a586ca70e4` |
| `research/tsla-d1-growth/results/search/C24/D-broad.json` | 932423 | `c1f92b9671c175f0cc79c57f3311e9bd18364c17316d0e5a431021df5cdf63ea` |
| `research/tsla-d1-growth/results/search/C24/D-refine.json` | 1020325 | `66a22fb4181bb17db862bd4c80071071b2a52d8d9805cefa2ff4872a8460f47b` |
| `research/tsla-d1-growth/results/search/C24/D-rx1.json` | 250151 | `d6c381b91cfaf1538235460c70d4b3ed511e2fb3770b362286cd13162a76d9c2` |
| `research/tsla-d1-growth/results/search/C24/D-rx2.json` | 232153 | `f98f6f2a17585f29051a11aa5c7a3fb4b978b0c1668d58ec19b7c301218ace75` |
| `research/tsla-d1-growth/results/search/C24/G-broad.json` | 2006023 | `911515b2c9a5a3e539e570aabce2c29d7bf2a3e388c42adb9e5976a6c0d52ec9` |
| `research/tsla-d1-growth/results/search/C24/G-refine.json` | 1502319 | `d55946da67fae19ff43ff766276f5d4ade51488abddf3f572e0a6cd5502babd6` |
| `research/tsla-d1-growth/results/search/C24/J-broad.json` | 6250510 | `02ef97bc264b429c182f7b70e85390f91f9155925cf2f26639fa1d87fb0435d9` |
| `research/tsla-d1-growth/results/search/C24/J-refine.json` | 4636483 | `6f5624b3eb497e13c9f4b3573db034920783974aac88b446bd4c6be34a587370` |
| `research/tsla-d1-growth/results/search/C24/S-broad.json` | 7227271 | `95a776526a5d7a401a844dae44ec387d13ec11c1ed9ad19724c37ff1c5adbfa4` |
| `research/tsla-d1-growth/results/search/C24/S-refine.json` | 3419190 | `bf898b54b314c9ee9c330bfb1318eed6910bc580a825cc65ffb92765b173da62` |

## 2. Official job archives of this study (Apollo only; git-ignored)

Every official job's SQLite archive, compressed per file with zstd after its cutoff completed and verified
(`study/storage/TSLA_JOB_ACTIONS.jsonl`: original sha256 and bytes, compressed sha256 and bytes, a restore test with
`PRAGMA integrity_check`, the evaluation ids reproduced). Paths: `research/tsla-d1-growth/results/jobs/<job>/` (job descriptors,
committed) and `research/tsla-d1-growth/cache/jobs/<job>/archive.sqlite.zst` (Apollo). Restore: `zstd -d -q <archive>.zst -o <archive>`,
then compare with the recorded sha256. Reproduction without them: rerun the official chain at `447ac7cee7b263a27297df6e79f29b52bbcf4e70`
(`study/chains/chain.sh`, `RUN_COMMANDS.md`) — seeds, budgets and doors are frozen and E5 showed lane-level
determinism, so a missing archive means recomputation, not a different result.

Current on-disk sizes: 17723286200 bytes under `research/tsla-d1-growth/cache/jobs`.

## 3. Priority 5's compressed job archives (Apollo only)

29 archives under `research/vg-l0-n-successor/cache/jobs/<job>/archive.sqlite.zst`; inventory, actions and
post-verification in `study/storage/` (INVENTORY.json, ACTIONS.jsonl, POST_VERIFY.json); restore procedure in
`STORAGE_PRESERVATION_REPORT.md`.

## 4. Engineering, pilot, diagnostic and door caches (Apollo only; git-ignored)

`research/tsla-d1-growth/cache/engineering` 689105554 bytes; `research/tsla-d1-growth/cache/pilot` 2625403640 bytes; `research/tsla-d1-growth/cache/diagnostics` 100143829 bytes; `research/tsla-d1-growth/cache/doors` 354227975 bytes; `research/tsla-d1-growth/cache/independent` 408687 bytes; `research/tsla-d1-growth/cache/strategy-lab-scratch` 3044404 bytes; `research/tsla-d1-growth/cache/diag-test` 4370167 bytes; 
Regenerated by the engineering and diagnostic commands in `RUN_COMMANDS.md` (non-official).

## 5. Market data (local, git-ignored; licensed)

`data/TSLA/` (Alpaca SIP minute bars; `TSLA_DATA_AUDIT.json` gives partition hashes, coverage and the download
procedure). The door files each stage read are identified by bytes, rows, sha256 and last row in
`study/data/DOOR_PINS.json` and `PROTOCOL_FREEZE.json`. The independent Yahoo daily series used for the split check
and the pre-2016 tail stress is in `research/tsla-d1-growth/cache/independent/` (not redistributed).

## 6. GPU binary and toolchain

`research/gpu-phase7/build/gb7` sha256 `cb2ff30b9cb720c01d69e5195a8add9bcf37eb31f7ab85625a3d1a5c02c56a82` (2931304 bytes): rebuilt
reproducibly from the pinned sources by `tools/gpu-backend/verify-acceptance.sh --rebuild` (record `reference/config/gpu-backend/acceptance.json`).

## 7. Logs and dependencies

Per-stage logs `research/tsla-d1-growth/cache/logs/chain/*.log` (98 files, 1404234 bytes; the chain log is included as
`study/results/logs/chain.log`) and per-job logs stay on Apollo; `node_modules` is restored by `npm ci`.

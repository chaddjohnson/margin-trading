# GPU Phase 4 — concurrency, batching, final acceptance: handoff bundle

Start with `GPU_CONCURRENCY_FINAL_HANDOFF.md`. The five reports and `MANIFEST.json` at this level are copies of the files
in `research/gpu-phase4/`; paths such as `results/…` inside the reports are relative to that directory, where the
machine-readable evidence lies. `summaries/` holds the benchmark summaries (SUMMARY.json, groups.csv, jobs.csv) and the
frozen-rule decisions. `CHECKSUMS.sha256` lists the sha256 of every file (`sha256sum -c CHECKSUMS.sha256`).
Risk-envelope pilot NOT STARTED.

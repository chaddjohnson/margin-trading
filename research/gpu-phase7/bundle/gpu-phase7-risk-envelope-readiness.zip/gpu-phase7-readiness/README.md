# GPU Phase 7 readiness package (risk-envelope pilot prerequisites)

Start with `research/gpu-phase7/PREREQUISITES_READY.md` (deliverable A). Deliverables: A PREREQUISITES_READY, B RISK_METRIC_INTEGRATION_SPEC, C PARITY_REPORT, D ACCEPTANCE_EVIDENCE (all research/gpu-phase7/), E PROTOCOL_PROPOSED + DECISION_REGISTER, G EXECUTION_PLAN (research/vg-l0-risk-envelope-pilot/), F RESTORATION_REPORT, H READINESS_MANIFEST.json (research/gpu-phase7/). `backend-change.patch` = the backend diff against the post-cleanup base d89b9dec. SHA256SUMS lists every file. No datasets or archives are included.

Branch research/gpu-phase7-risk-envelope-readiness at 269128fbf47d7e4ed9d3b7cb17a121103428c1c9.

**PILOT NOT STARTED — awaiting original-conversation review and separate authorization**

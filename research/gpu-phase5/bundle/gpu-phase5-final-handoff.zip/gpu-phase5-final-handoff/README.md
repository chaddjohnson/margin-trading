# GPU Phase 5 — parity root cause, atomic dataset cache, performance audit, acceptance and integration: handoff bundle

READ FIRST: `GPU_FINAL_HANDOFF.md` (status, the accepted version and its record sha256, the merged revision or the
reason none was made, the checked-out branch, risks). Then, as needed:

| File | Content |
|---|---|
| `PARITY_ROOT_CAUSE.md` | the Phase 4 mismatch: evidence, cause, fix, attribution limits |
| `ATOMIC_CACHE_AND_CONCURRENCY.md` | the atomic dataset export, its tests, job isolation, the 1-job / 2-job modes |
| `PERFORMANCE_AUDIT.md` | profiles, every candidate (kept or rejected), end-to-end timings against Phase 3 |
| `GPU_ACCEPTANCE_REPORT.md` | every gate with its counts, hashes and evidence files; diagnostics |
| `MERGE_AND_RESTORE.md` | commits, the merge and its verification, or the exact reason no merge occurred |
| `PILOT_HANDOFF_ONLY.md` | context for the pilot's owner — **RISK-ENVELOPE PILOT NOT STARTED** |

The seven reports and `MANIFEST.json` at this level are copies of the files in `research/gpu-phase5/`; paths such as
`results/…` inside the reports are relative to that directory, where the machine-readable evidence lies (JSON, JSONL,
CSV, the campaign's unit logs under `results/runlogs/`). `summaries/` holds the main machine-readable summaries.
`research/gpu-phase5/{PROTOCOL.md,AMENDMENTS.md,RUN_COMMANDS.md,RESEARCH_RECOVERY.md,brief/BRIEF.md}` are the method,
its changes, the exact commands and the checkpoint. Verify the bundle with `sha256sum -c CHECKSUMS.sha256` inside the
extracted directory. No market data, binaries, caches or credentials are included.

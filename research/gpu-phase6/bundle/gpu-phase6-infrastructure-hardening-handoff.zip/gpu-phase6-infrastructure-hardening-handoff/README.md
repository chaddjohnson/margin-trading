# GPU Phase 6 handoff — read GPU_INFRASTRUCTURE_HARDENING_REPORT.md first

GPU infrastructure hardening completed. Risk-envelope pilot NOT STARTED.

Reading order: GPU_INFRASTRUCTURE_HARDENING_REPORT.md; research/gpu-phase6/JOB_ISOLATION.md; research/gpu-phase6/MERGE_AND_RESTORE.md;
research/gpu-phase6/PROTOCOL.md and AMENDMENTS.md; research/gpu-phase6/results/ (campaign/summary.json, compare/, parity/, policy/,
tests/, integrity/, integration/); config/gpu-backend/acceptance.json (sha256 in the report). CHECKSUMS.sha256 lists every file.

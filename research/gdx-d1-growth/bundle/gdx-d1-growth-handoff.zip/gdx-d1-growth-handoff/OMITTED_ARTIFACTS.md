# OMITTED ARTIFACTS — P8-GDX handoff

Nothing below is needed to read the findings; everything is needed only to replay or audit at lane level.
Sizes in bytes; sha256 recomputed at packaging.

## 1. Per-lane search and qualification records (in the repository, not in the ZIP)

Committed on branch `research/gdx-d1-growth` at `c1e6ba14841a2e60c6e55e82f3ef5c8dacf3b3c9` (and sealed: `study/results/seals.jsonl`). Restore:
`git fetch origin research/gdx-d1-growth && git checkout c1e6ba14841a2e60c6e55e82f3ef5c8dacf3b3c9 -- <path>`. Compact per-lane summary in the ZIP:
`study/reports/tables/lanes.csv` (one row per lane: islands, requested, stop reason, best feasible net).

| Path | Bytes | sha256 |
|---|---:|---|
| `research/gdx-d1-growth/results/qualification/C19/C-fixed.json` | 174215 | `0afdc4cdbcaf051b44ee40e86cd55a2d8f2e57e38a771c792929a7b69b2125b3` |
| `research/gdx-d1-growth/results/qualification/C19/D-broad.json` | 2503661 | `c7d496c38d4cc7854cf957d408d45f6565b8332bdac60b39b3c75cba33321dcc` |
| `research/gdx-d1-growth/results/qualification/C19/D-refine.json` | 4247407 | `0b7d4f33bcb083e8946a78f95257192a87f31c12cc521cf9267ed43e150ba920` |
| `research/gdx-d1-growth/results/qualification/C19/G-broad.json` | 4102322 | `9f4e3be82a5b93272cf970236dfcf2f7b0a361765e850eba807e8cb66742cc3d` |
| `research/gdx-d1-growth/results/qualification/C19/G-refine.json` | 3329679 | `3e427e76bcb8e57fc9e84af4a1ff0dc0a002572eb466173669a74c7a125e6927` |
| `research/gdx-d1-growth/results/qualification/C19/J-broad.json` | 16738431 | `8acf564da554fa72fd6ba9b3f70f15b46f393c4cdbd426bc1fa9b6986d275a9e` |
| `research/gdx-d1-growth/results/qualification/C19/J-refine.json` | 9769451 | `a118843007711a029b98f8554b61d8ba2fc89f74d5bdb5e303545358d0f5e0d0` |
| `research/gdx-d1-growth/results/qualification/C19/S-broad.json` | 14489434 | `cea8b8718b3fc6668c339a966c3477b6d553172199352aeec89779fd32e07f73` |
| `research/gdx-d1-growth/results/qualification/C19/S-refine.json` | 7448091 | `0fc54975cfdc66c7005fab9a942841c69a9ed44d17db161f81fed2cac7bdf1f2` |
| `research/gdx-d1-growth/results/qualification/C21/C-fixed.json` | 176384 | `eb68de9355c2bb08d4332a27b2bb5f697d92d8d910f2c1f29a1a42a368a75e27` |
| `research/gdx-d1-growth/results/qualification/C21/D-broad.json` | 2530393 | `8629a0265e3ac033d1f7ad1f973bc8d771ce80fe4f78fabf40754b2a0dca7d99` |
| `research/gdx-d1-growth/results/qualification/C21/D-refine.json` | 4584760 | `73255d3bc85b5f1e05ea48d3e409180380f36b300435dd32aa8c190afc6ffab2` |
| `research/gdx-d1-growth/results/qualification/C21/G-broad.json` | 4068822 | `6bb58ce3674f6fa8852f16bbc30710b400e980dd2edae2947926f45e049a0fec` |
| `research/gdx-d1-growth/results/qualification/C21/G-refine.json` | 3390735 | `d11b7899a41e157140e9b46378a3e63ba976257f48771aec2c3bc5d785d6678c` |
| `research/gdx-d1-growth/results/qualification/C21/J-broad.json` | 16774595 | `0b48acdad4a2fe7b39b7ff495c23bed5e99a1df1f7734202cb0cf82d386dc68f` |
| `research/gdx-d1-growth/results/qualification/C21/J-refine.json` | 10288471 | `102ff990c501c323627125d591ced07ddf975f87828dd517b89e392f9ba82df0` |
| `research/gdx-d1-growth/results/qualification/C21/S-broad.json` | 14776171 | `3ef3e1edfdda9bfc6620fddb2fc74b5ac255983c02ccc1610d59d1b6badf5c6d` |
| `research/gdx-d1-growth/results/qualification/C21/S-refine.json` | 7542949 | `fea78a63578fbc8fbf222a512a680dd68f0223af2741ab1fa807c9f117e9a70f` |
| `research/gdx-d1-growth/results/qualification/C23/C-fixed.json` | 174733 | `19489400f0dcc06236bc357646105c38198d111a2e337f32da35f97060ebb52d` |
| `research/gdx-d1-growth/results/qualification/C23/D-broad.json` | 2931211 | `217ebc8bd8638d1d13a83a587dbe9030f35ccd52d833636a45c0818a80a05206` |
| `research/gdx-d1-growth/results/qualification/C23/D-refine.json` | 4335955 | `b1aa80ad11442c4edf1c424f826f9a1821582f69708654d23328ebb2e66103ca` |
| `research/gdx-d1-growth/results/qualification/C23/G-broad.json` | 3793043 | `87c6ac780ea9bdd3e1fd1c27d820ad200a008a6c0ab056a90aad13574cdbe6a3` |
| `research/gdx-d1-growth/results/qualification/C23/G-refine.json` | 3276697 | `9ac6ff3d6c113b84d873f55512cb737c6affaf4e74a523b273551568ea35c5a4` |
| `research/gdx-d1-growth/results/qualification/C23/J-broad.json` | 19433664 | `350c5995a8ba92a59e0ac016d6fcca25bb90ff297a2e37b4c6f5b6f62618ff72` |
| `research/gdx-d1-growth/results/qualification/C23/J-refine.json` | 9958817 | `7698f9997bd170b0d58d49298344a2b573852edf1e70ee15ade248d8ea30c781` |
| `research/gdx-d1-growth/results/qualification/C23/S-broad.json` | 14641082 | `647b6ab84a045a9c83b6e9240cb2b06ae6a5a940a6bb833b6254c0d32016d6d8` |
| `research/gdx-d1-growth/results/qualification/C23/S-refine.json` | 7439660 | `34f5da3418771651e57aa77244345d8ae343eae3507bbf4f4eeffa92370e6a9e` |
| `research/gdx-d1-growth/results/qualification/C24/C-fixed-informed.json` | 79772 | `c11dbb15e339be889c7b470461f38492beee778fae0962a74435880788746eec` |
| `research/gdx-d1-growth/results/qualification/C24/C-fixed.json` | 118205 | `0794e27fe10c525ffd944b20e1c89be02aed6154c4716a7ef3861d5e160afb15` |
| `research/gdx-d1-growth/results/qualification/C24/D-broad.json` | 2525114 | `6c0cb06f964cb2103f0fe05e910d06394ef1f6ef437b262c1ac6e59bace53385` |
| `research/gdx-d1-growth/results/qualification/C24/D-informed.json` | 782613 | `c4d5d48c16550f31abe5072b8af4e89dd8b47f58a9ed0bed345516722a6874b7` |
| `research/gdx-d1-growth/results/qualification/C24/D-refine.json` | 4221771 | `8d055bf4d21b6cef8414fa0cea0805bf3225553f46cb09b536fc66d4b7711c47` |
| `research/gdx-d1-growth/results/qualification/C24/G-broad.json` | 3795367 | `ca36b940444f5785cde70e3e4ea1c41f3378e677f1b8102e6befbbc16e302499` |
| `research/gdx-d1-growth/results/qualification/C24/G-informed.json` | 1659892 | `2a8d6dbb0bd1a418c6e27b26b32565e888a41a9d874fa8867520711cbb11ffb9` |
| `research/gdx-d1-growth/results/qualification/C24/G-refine.json` | 3293196 | `ad573c891d47e401ba431b566608c1f74e6043e868d1e72769e187fff7806fcd` |
| `research/gdx-d1-growth/results/qualification/C24/J-broad.json` | 16725156 | `4a6cca6104ce4542f12b40da649c511ef7b64181a3fa44ad5eb5044f957f7b18` |
| `research/gdx-d1-growth/results/qualification/C24/J-refine.json` | 10097482 | `98e95936ca913a35a56e130e0c3ead13d5734c226b69c2bec14c9b284a496d8a` |
| `research/gdx-d1-growth/results/qualification/C24/S-broad.json` | 14049531 | `cbbebf313a512afcea1dee96f24263ddb4e2d61dc12952d5a279dcf5b84dc51c` |
| `research/gdx-d1-growth/results/qualification/C24/S-refine.json` | 7827443 | `098900349f5470d805f2d48c078eadcc3d2a2720f5b19b5ef6e6e084fad0c893` |
| `research/gdx-d1-growth/results/search/C19/D-broad.json` | 1893634 | `a775284291e4f6c3d411c7899b7d1e764166e688a328b24fc0d14510e93e66e1` |
| `research/gdx-d1-growth/results/search/C19/D-refine.json` | 2900617 | `d9e9204b0d2e7cf0044a3d2a07422ee4795a280c2a2b0c1cf53a60d8e18889b5` |
| `research/gdx-d1-growth/results/search/C19/G-broad.json` | 2909895 | `6de5cb696ec9c0326ed05624fc660cc61807ca2d4fe0dacf86d33749402cffa6` |
| `research/gdx-d1-growth/results/search/C19/G-refine.json` | 2241647 | `1488a99b5cf31dcffc740b59c0fe5510aa1ef4732fb4974de770705086049bfc` |
| `research/gdx-d1-growth/results/search/C19/G-rx1.json` | 252987 | `6b6a9dd1fdb46358a2284a7cd99332ad83db82f9564325b946f8b51678bb65af` |
| `research/gdx-d1-growth/results/search/C19/J-broad.json` | 13751263 | `6cdd88bb73f1aa0a695adbd059c9365efd8b071642d6b1544a32050d261740c3` |
| `research/gdx-d1-growth/results/search/C19/J-refine.json` | 6872141 | `7ac7b52c82cd4b46dfac5a3362257904cdfd1a46826fbbf577663c995c48e3b2` |
| `research/gdx-d1-growth/results/search/C19/S-broad.json` | 10772066 | `566843b77827a5244b48de0bc0832a44c7e1fe8a11d4351171c9a4ab95b68aa8` |
| `research/gdx-d1-growth/results/search/C19/S-refine.json` | 4866105 | `cf24f99897e3b3e343d3933ceebb33782479b2418bf0d44aafdebba8df80daa3` |
| `research/gdx-d1-growth/results/search/C21/D-broad.json` | 1870621 | `6d001bfa3fcb31edb26797dc86420353d9cdb2f0f235464bebd0ccff1f05a0af` |
| `research/gdx-d1-growth/results/search/C21/D-refine.json` | 2940318 | `bd82a159dedcf043e4907f1949c5159547f35ec212f05bb88c47bbe586533c61` |
| `research/gdx-d1-growth/results/search/C21/G-broad.json` | 2883808 | `b4043b28e07a367f79625a3d4643a74d4481a5f783256bf90895e695aebc4384` |
| `research/gdx-d1-growth/results/search/C21/G-refine.json` | 2234847 | `d6474ce3393ae5fcbe2dce0230b195fc74fadc4e5dc49ce6852e414bace1bb61` |
| `research/gdx-d1-growth/results/search/C21/G-rx1.json` | 251870 | `0d9b7abac3360c9b05d9c00613ebc9b89fea1bd147e48533fefec3ef11a5776e` |
| `research/gdx-d1-growth/results/search/C21/J-broad.json` | 13833182 | `860b70bfc4ae34ba235cbf3083d3d79b045f45eb94d3e84f73a90d65a030a45e` |
| `research/gdx-d1-growth/results/search/C21/J-refine.json` | 6962891 | `9c1f8d6e9b4ca76cba2135a740939ab2270c3f798827b49d1ce5df0d5863e3b3` |
| `research/gdx-d1-growth/results/search/C21/S-broad.json` | 10960981 | `e74449fdba00a501402f67fec97a1bc83203de0b0d6f4f368a45f39b45b297ff` |
| `research/gdx-d1-growth/results/search/C21/S-refine.json` | 5028068 | `2b05a88cad853d7f6d56e0d6f511b4f9596c619c699cd370eae4a314ab90740c` |
| `research/gdx-d1-growth/results/search/C23/D-broad.json` | 1868582 | `0066259cb6a573b03d459199baa9f1e21770ef977355ec0650a0f7d8b91d02d7` |
| `research/gdx-d1-growth/results/search/C23/D-refine.json` | 2982111 | `f847afdaf91f79aca787ba6358d18facbb7f964928db3a9d097527b2ca675600` |
| `research/gdx-d1-growth/results/search/C23/D-rx1.json` | 314939 | `384869fb57ad671070ed4734b3ab7d525084c633dc6a9ba38ca7e61436029af9` |
| `research/gdx-d1-growth/results/search/C23/G-broad.json` | 2915068 | `689e60ee6e3d332f76286755c667480bfdd15706b078a049f3468b68113d5391` |
| `research/gdx-d1-growth/results/search/C23/G-refine.json` | 2262037 | `74efd9790523a2fb4f15bc163cd148e2b2c1604b6f5d3e0d25c818c8fc97b583` |
| `research/gdx-d1-growth/results/search/C23/J-broad.json` | 13803039 | `c3d9a48473b08329715d2b7576038390a1dad49a602535aac01930ab011688b1` |
| `research/gdx-d1-growth/results/search/C23/J-refine.json` | 6945765 | `917901ca7b514e16997d07aace3a7f93e32510122ea25f1976713af397c7fe55` |
| `research/gdx-d1-growth/results/search/C23/J-rx1.json` | 2294825 | `971f186b854d580b126a0da1102d7001ecd49c8ba9eb5d81f8567b0aefdd5ea8` |
| `research/gdx-d1-growth/results/search/C23/S-broad.json` | 10923770 | `2b81e60c37b67c4c18693e28e60dcede480d914bf2d5ab48cd1e8fb573eeccef` |
| `research/gdx-d1-growth/results/search/C23/S-refine.json` | 5039031 | `326fbe8a716cf8c566c178fa109eb3f970a4398a38408bbcfdedc4fce2771d67` |
| `research/gdx-d1-growth/results/search/C24/D-broad.json` | 1884200 | `c485a3b6882fd80809531688097edb1476bc531e724962d6aef2b831121afbf7` |
| `research/gdx-d1-growth/results/search/C24/D-informed.json` | 564469 | `6ada5dee7e41e3172d2af1825968e83814e82e494a3bce1e1b82cad9b4571608` |
| `research/gdx-d1-growth/results/search/C24/D-refine.json` | 2989975 | `ab1199d81d3a74a4feeced4ac7946ca1ddb10c803b8ed8fa628bedaf5543ad5f` |
| `research/gdx-d1-growth/results/search/C24/G-broad.json` | 2942978 | `606ec4ae8403651383ddf6ab7f98443559eb6c36046698bd4e58e37a4f17bb14` |
| `research/gdx-d1-growth/results/search/C24/G-informed.json` | 1106720 | `bbc12059a7840145220f162c0e9b1253fe373d6cf29f5993a0477afea1ef41fc` |
| `research/gdx-d1-growth/results/search/C24/G-refine.json` | 2268404 | `fa45627165c0f48b26faba8cf0e34e4ce5c0e420aa3919513e9b6582557ca190` |
| `research/gdx-d1-growth/results/search/C24/J-broad.json` | 13843015 | `8f61b9efd0d296722856c8818f665f287a721b318bea126e09e068b0acfa6bbc` |
| `research/gdx-d1-growth/results/search/C24/J-refine.json` | 7063732 | `e39ab96d9d5c0609e3800d0eb2456a96c4f2ae346a88e039ed84d6a3f4792983` |
| `research/gdx-d1-growth/results/search/C24/S-broad.json` | 10700747 | `330ecdb9a8891d6f930bea5d6e0a3f3efa1f92627450bb82322a44d45de695a3` |
| `research/gdx-d1-growth/results/search/C24/S-refine.json` | 5137022 | `9fa61f91ee1db714d44dead65cc7ec3fe5aea00812bb5feae5f70024d1c56b96` |

## 2. Official job archives of this study (Apollo only; git-ignored)

Every official job's SQLite archive, compressed per file with zstd after its cutoff completed and verified
(`study/storage/GDX8_JOB_ACTIONS.jsonl`: original sha256 and bytes, compressed sha256 and bytes, a restore test with
`PRAGMA integrity_check`, the evaluation ids reproduced). Paths: `research/gdx-d1-growth/results/jobs/<job>/` (job descriptors,
committed) and `research/gdx-d1-growth/cache/jobs/<job>/archive.sqlite.zst` (Apollo). Restore: `zstd -d -q <archive>.zst -o <archive>`,
then compare with the recorded sha256. Reproduction without them: rerun the official chain at `c1e6ba14841a2e60c6e55e82f3ef5c8dacf3b3c9`
(`study/chains/chain.sh`, `RUN_COMMANDS.md`) — seeds, budgets and doors are frozen and E5 showed lane-level
determinism, so a missing archive means recomputation, not a different result.

Current on-disk sizes: 26187956104 bytes under `research/gdx-d1-growth/cache/jobs`.

## 3. The total-portfolio daily series

`study/reports/portfolio/series/*.csv` (one per scenario, primary leverage and variant) are in the ZIP; the other
leverage levels and variants are reproducible with `npm run gdx8-port -- run` (RUN_COMMANDS.md).

## 4. Engineering, pilot, diagnostic and door caches (Apollo only; git-ignored)

`research/gdx-d1-growth/cache/engineering` 662122977 bytes; `research/gdx-d1-growth/cache/pilot` 4173495419 bytes; `research/gdx-d1-growth/cache/diagnostics` 101276613 bytes; `research/gdx-d1-growth/cache/doors` 269879600 bytes; `research/gdx-d1-growth/cache/independent` 566152 bytes; `research/gdx-d1-growth/cache/strategy-lab-scratch` 3044404 bytes; `research/gdx-d1-growth/cache/diag-test` 3271192 bytes; 
Regenerated by the engineering and diagnostic commands in `RUN_COMMANDS.md` (non-official).

## 5. Market data (local, git-ignored; licensed)

`data/GDX/`, `data/VOOG/`, `data/VGT/` (Alpaca SIP minute bars; `GDX_DATA_AUDIT.json` gives hashes and coverage; the
core files' hashes are in `study/reports/portfolio/portfolio.json`). The door files each stage read are identified by bytes, rows, sha256 and last row in
`study/data/DOOR_PINS.json` and `PROTOCOL_FREEZE.json`. The independent Yahoo daily series used for the split check
and the pre-2016 tail stress, and the distribution events, are in `research/gdx-d1-growth/cache/independent/` (not redistributed).

## 6. GPU binary and toolchain

`research/gpu-phase7/build/gb7` sha256 `cb2ff30b9cb720c01d69e5195a8add9bcf37eb31f7ab85625a3d1a5c02c56a82` (2931304 bytes): rebuilt
reproducibly from the pinned sources by `tools/gpu-backend/verify-acceptance.sh --rebuild` (record `reference/config/gpu-backend/acceptance.json`).

## 7. Logs and dependencies

Per-stage logs `research/gdx-d1-growth/cache/logs/chain/*.log` (97 files, 2039516 bytes; the chain log is included as
`study/results/logs/chain.log`) and per-job logs stay on Apollo; `node_modules` is restored by `npm ci`.

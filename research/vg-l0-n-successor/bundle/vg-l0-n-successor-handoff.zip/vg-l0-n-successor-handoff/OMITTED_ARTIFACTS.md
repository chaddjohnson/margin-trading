# OMITTED ARTIFACTS — P5-NS handoff

Nothing below is needed to read the findings; everything is needed only to replay or audit at lane level.
Sizes in bytes; sha256 recomputed at packaging (archives: `study/reports/diagnostics/*.sha256`).

## 1. Per-lane search and qualification records (in the repository, not in the ZIP)

Committed on branch `research/vg-l0-n-original-successor` at `9dfefef26907a2d9f4f236a65fbfe9d9073ae5f4` (and sealed: `study/results/seals.jsonl`). Restore:
`git fetch origin research/vg-l0-n-original-successor && git checkout 9dfefef26907a2d9f4f236a65fbfe9d9073ae5f4 -- <path>`. Compact per-lane summary in the ZIP:
`study/reports/tables/lanes.csv` (one row per lane: islands, requested, stop reason, best shortlisted member).

| Path | Bytes | sha256 |
|---|---:|---|
| `research/vg-l0-n-successor/results/qualification/C19/broad.json` | 25238635 | `d797c218d2fad837cbe13e2da29d75c01a9d1c4aff9f704aa74fccf9f2975c60` |
| `research/vg-l0-n-successor/results/qualification/C19/refine.json` | 6942923 | `33db19ab12484b1900d9d43cfa5fc4552db993a6d889979278e91b5183968e0f` |
| `research/vg-l0-n-successor/results/qualification/C21/broad.json` | 16980659 | `15074add5e3242a9e31e9aa8b461b49a1a5c1e4cb7db4e491163e8b93d8874f9` |
| `research/vg-l0-n-successor/results/qualification/C21/refine.json` | 6953510 | `e35629f351dfc0254ce14c0270331f2e47a6f24780241e51377e499dba0e9fe2` |
| `research/vg-l0-n-successor/results/qualification/C23/broad.json` | 16999866 | `c6494c216d622ffd645f64fb163c90fd8a390bc6ea60cd15271ce8349763f700` |
| `research/vg-l0-n-successor/results/qualification/C23/refine.json` | 6383046 | `0fcd7f60b3fe13116784d7e614b55d2ac8626a9bc6195e465a62a3a8ad8baa07` |
| `research/vg-l0-n-successor/results/qualification/C24/broad.json` | 16897133 | `ef00e429b04fd7aa4c4567e126837dafee3890e2da06b5bc3c33d297a79efcb4` |
| `research/vg-l0-n-successor/results/qualification/C24/informed.json` | 15725229 | `e39a04452426077ab516b1f32d3bfa55ff9a0727cb25361252ca17991ecb025a` |
| `research/vg-l0-n-successor/results/qualification/C24/refine.json` | 6164998 | `481b4002e6ce589efb344f7a87258473488d0813619310c5ad02a8d09f6c3c48` |
| `research/vg-l0-n-successor/results/search/C19/broad1.json` | 8170791 | `6e252f5bea63d54e584eacd6f1d771c19f31fb3324ef705c664d1da5cf710d51` |
| `research/vg-l0-n-successor/results/search/C19/broad2.json` | 9137035 | `0373d3ee5c359c061e026cd59ecd70ecc8c7389475c1061396577c708c76653d` |
| `research/vg-l0-n-successor/results/search/C19/refine.json` | 4845896 | `f7aa4eefef70420b6f50f55524aaa374ca2f7ab45c1a9ec5fd249148884bcf1d` |
| `research/vg-l0-n-successor/results/search/C19/rx1.json` | 4345756 | `684c8c763cb086bdae3d33818d75cee4ee604ddbec8b816f5815ec1dc00a4d60` |
| `research/vg-l0-n-successor/results/search/C19/rx2.json` | 4332279 | `ef64fa20e4d1ce40dbe1c1c55d52ba5feedf762df8d53a8458376ef033c9da5f` |
| `research/vg-l0-n-successor/results/search/C21/broad1.json` | 8212984 | `0cd4c8b7ba7786ddd342d7c91147b6f4157dd0c25fa6b76011dc2b6bcce013ae` |
| `research/vg-l0-n-successor/results/search/C21/broad2.json` | 9207584 | `e3df300f61f9c72e8b43dc3c9eef32cd1028d3152bbbdab3e18e76a8f8d3241a` |
| `research/vg-l0-n-successor/results/search/C21/refine.json` | 4933525 | `31ce6acb41d0a6fa50b0eb989c775416472c69d361afea313a40f4558635d431` |
| `research/vg-l0-n-successor/results/search/C23/broad1.json` | 8246325 | `040a34b95729eb46aa2e6be22c3201474642a0a1542682805b8d535028ab658e` |
| `research/vg-l0-n-successor/results/search/C23/broad2.json` | 9148060 | `384ea019f854621dfc1d8442c36a72ea502b0fc9190a009103dfe38208688612` |
| `research/vg-l0-n-successor/results/search/C23/refine.json` | 4469147 | `e165df2c2453b315d5b679482f50a6fffde93971d6679f7e87d626331624ecec` |
| `research/vg-l0-n-successor/results/search/C24/broad1.json` | 8242824 | `29b27c17eca215c15c7464d1393b572a1e51bf2ab66665213a9525869c338f5d` |
| `research/vg-l0-n-successor/results/search/C24/broad2.json` | 9141814 | `2579edc57ee466763d395473a9f09600dbe99f2bae8a3dee9683c67be89f697b` |
| `research/vg-l0-n-successor/results/search/C24/informed1.json` | 6327486 | `0381bcd8ed5d801c3fc70291036ec2d25ffdccc33b68ebad9d03d7fa1cff250c` |
| `research/vg-l0-n-successor/results/search/C24/informed2.json` | 6943620 | `99c10b84730db0293ca932018c25c4e9896f234d7fa355c5aa0cba1e1e556f87` |
| `research/vg-l0-n-successor/results/search/C24/refine.json` | 4558429 | `28218b79dde073fc302c083b14073649bb5833522c5cd7b698e04e53a5bde35e` |

## 2. Official job archives (Apollo only; git-ignored)

29 SQLite archives under `research/vg-l0-n-successor/cache/jobs/<job>/archive.sqlite`, 196.0 GB in all; each
line of `study/reports/diagnostics/job-archives.sha256` is `sha256  bytes  path`. They are kept **uncompressed until
the user's review** (DECISION_REGISTER F3). Reproduction without them: rerun the official chain at `9dfefef26907a2d9f4f236a65fbfe9d9073ae5f4`
(`study/chains/chain.sh`, `RUN_COMMANDS.md`) — seeds, budgets and doors are frozen, so the sealed records reproduce
(E3/E5 showed lane-level determinism); a missing archive means recomputation, not a different result.

## 3. Engineering, pilot and diagnostic caches (Apollo only; git-ignored)

`research/vg-l0-n-successor/cache/engineering`, `research/vg-l0-n-successor/cache/pilot`, `research/vg-l0-n-successor/cache/diagnostics`, `research/vg-l0-n-successor/cache/lot-rows`, `research/vg-l0-n-successor/cache/strategy-lab-scratch`:
research/vg-l0-n-successor/cache/engineering 3138205107 bytes; research/vg-l0-n-successor/cache/pilot 17525251124 bytes; research/vg-l0-n-successor/cache/diagnostics 175774615 bytes; research/vg-l0-n-successor/cache/lot-rows 18836489 bytes; research/vg-l0-n-successor/cache/strategy-lab-scratch 3044404 bytes; 
files over 1 MB hashed in `study/reports/diagnostics/other-caches.sha256`. Regenerated by the engineering and
diagnostic commands in `RUN_COMMANDS.md` (non-official).

## 4. Market data (local, git-ignored)

`data/GDX/`, `data/VGT/` (and the tail-stress proxies `data/GDXJ/`, `data/XLK/`). The door files each stage read
are identified by bytes, rows, sha256 and last row in `PROTOCOL_FREEZE.json` → `doors` (D19, D21, D23, D24, FULL);
see `docs/canonical-dataset-migration.md` in the repository for the dataset layout.

## 5. GPU binary and toolchain

`research/gpu-phase7/build/gb7` sha256 `cb2ff30b9cb720c01d69e5195a8add9bcf37eb31f7ab85625a3d1a5c02c56a82` (2931304 bytes): rebuilt
reproducibly from the pinned sources by `tools/gpu-backend/verify-acceptance.sh --rebuild` (record `reference/config/gpu-backend/acceptance.json`).

## 6. Logs and dependencies

Per-stage logs `research/vg-l0-n-successor/results/logs/*.log` (56 files, 1347901 bytes; the chain log is included as
`study/results/logs/chain.log`) and per-job logs `research/vg-l0-n-successor/results/jobs/*/logs/` stay on Apollo; `node_modules` is restored
by `npm ci`.
